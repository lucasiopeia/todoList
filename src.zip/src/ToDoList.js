import React, { Component } from 'react'

export default class TodoList extends Component {

    render() {
        return (
            <div className="to-do-list-main">
                <tr>
                    <td>
                        <input type="checkbox"></input>
                    </td>
                    <td>{this.props.name}</td>
                 

                </tr>
            </div>

        )
    }
}
