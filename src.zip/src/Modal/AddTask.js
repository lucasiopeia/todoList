import React, { Component } from 'react';

class AddTask extends Component {
    constructor(props) {
        super(props)
        this.state = {
            name: '',
        }
    }
    //nhan state tu component addtask
    handleAddTask = () => {
        this.props.addTask(this.state.name)

    }
    //get value tu input type -> state name
    isChangedName = (e) => {
        this.setState({
            name: e.target.value
        })
    }
    
    render() {
        return (

            <div className="container">
                <h2>Add New Task</h2>
                <div className="form-group">
                    <label>Name</label>
                    <input type="text" className="form-control" placeholder="Enter name of task" onChange={this.isChangedName} />
                </div>
                <button type="submit" className="btn btn-danger" onClick={this.handleAddTask}>Add</button>

            </div>

        );

    }
}

export default AddTask;