import React from 'react'
import './CompletedBox.css';

const CompletedBox = () => (
  <div className="CompletedLayout">

                <h2>List Task</h2>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th>Name of task</th>
                        </tr>
                    </thead>
                    
              </table>
          </div >
)

export default CompletedBox