import React, { Component } from 'react';
import './IncompletedBox.css';
import ToDoList from '../ToDoList';

//Xu ly cac Task
class IncompletedBox extends Component {
    constructor(props) {
        super(props)
        this.state = {
            tasks: ['You got me feeling like a psycho', 'You got me feeling like a psycho'],
        }
    }
 
    render() {
        
        return (
            <div className="incompletedLayout">
                
                <table className="table table-responsive">
                    <thead>
                        <tr>
                            <th>Name of task</th>   
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.tasks.map(function (name, index) {
                                return <ToDoList name={name}/>
                            })
                        }
                    </tbody>
                    
                </table>
            </div >
        );
    }
}

export default IncompletedBox